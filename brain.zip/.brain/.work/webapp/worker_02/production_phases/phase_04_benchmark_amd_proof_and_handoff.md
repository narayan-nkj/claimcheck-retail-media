# Worker 02 P-04 — Benchmark, AMD Proof, and Handoff

## Objective
Produce honest, repeatable inference measurements and final AMD evidence.

## Scope
Define latency/throughput/cost proxy protocol, denominator, environment disclosure, request tracing, screenshots/logs, and demo proof.

## Dependencies
P-01 through P-03; submission and demo plans.

## Expected outputs
Benchmark protocol; AMD proof bundle; limitations; final handoff.

## Production validation
Define and execute unit, contract, integration, security, reliability, observability, and operational checks appropriate to this phase. Record evidence and limitations.

## Production acceptance criteria
Every metric is reproducible and qualified; offline fallback is never presented as AMD execution.

## Handoff
Worker 03 integrates proof into the release package; Tester 02 signs off.

## Report

`.brain/.work/.report/worker_02_p04_report.md` is mandatory before this phase can close.

## Atomic execution plan

Break this phase into the following atomic steps. The owner may split a step further if the repository, research, or risk review shows that it is still too large. Do not combine steps merely to reduce the number of commits.

| Step | Atomic activity | Required evidence | Step-specific validation | Commit/push requirement |
|---|---|---|---|---|
| 4.01 | Inspect current repository state, branch, remote, relevant files, and incoming changes. | State snapshot and dependency notes. | `git status`, branch/remote inspection, conflict check. | Commit only if planning artifacts change; push the state/report update. |
| 4.02 | Convert the phase objective into the smallest implementable contract or change. | Contract or decision record. | Schema/type/consistency review. | Small descriptive commit and push. |
| 4.03 | Implement or specify the first independently reviewable unit. | Files, schemas, or planning artifacts changed. | Unit/contract/documentation test for the unit. | Small descriptive commit and push. |
| 4.04 | Add failure, abuse, privacy, and boundary behavior. | Failure matrix and mitigation record. | Negative, security, and privacy checks. | Small descriptive commit and push. |
| 4.05 | Add observability, auditability, and operational evidence. | Logs, metrics, traces, audit, or runbook requirements. | Observability/readiness verification. | Small descriptive commit and push. |
| 4.06 | Integrate with the next contract or dependent workstream. | Integration notes and compatibility evidence. | Contract/integration test. | Small descriptive commit and push. |
| 4.07 | Review documentation, traceability, and release impact. | Updated report, matrix, decisions, risks, and handoff. | Documentation and traceability check. | Small descriptive commit and push. |
| 4.08 | Perform phase-level validation and prepare the handoff. | Test output, defect list, signoff recommendation. | Full phase test suite and regression checks. | Final phase commit and push. |

### Mandatory step-close checklist

For **each** atomic step, the Worker 02 must record:

- exact files and lines changed;
- test or validation command;
- expected and actual result;
- defects found and resolution;
- security/privacy/secret scan result;
- documentation and traceability updates;
- commit message and full commit hash;
- remote name and branch;
- push result and pushed commit hash;
- rollback or recovery action if the push or test fails.

### Final phase test-and-push gate

After all atomic steps complete, run the complete phase test suite, the relevant regression suite, security checks, documentation checks, and integration checks. Fix all failures. Then create the phase report at `.brain/.work/.report/worker_02_p04_report.md`, update the handoff and status files, commit all phase-final artifacts, push to GitHub, and record the final commit hash and push result. The phase remains **INCOMPLETE** until this gate passes.

Do not claim GitHub synchronization unless the push command succeeded and the remote branch contains the recorded commit.
